class Questions{
  String que;
  bool ans;
  Questions(this.que,this.ans);
}