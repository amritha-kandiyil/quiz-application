package com.example.quiz

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
